import americano from './americano.png'
import cafeLatte from './cafelatte.png'
import vanillaLatte from './vanillalatte.png'
import cafeMocha from './cafemocha.png'
import chocoLatte from './choco.png'
import strawberryLatte from './strawberry.png'
import bananaLatte from './banana.png'
import greenTeaLatte from './greentea.png'

const images =  {
    americano, cafeLatte, vanillaLatte, cafeMocha, chocoLatte, strawberryLatte, bananaLatte, greenTeaLatte
}

export default images